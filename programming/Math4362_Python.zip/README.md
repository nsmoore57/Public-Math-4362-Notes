# Course Environment Setup

Welcome to the Python environment for our course. This folder contains the configuration and directory structure you will need to organize your coursework and run our machine learning and numerical analysis computations. 

## Folder Structure

*   **`pyproject.toml` & `uv.lock`**: Configuration files that tell the package manager exactly which Python packages (such as NumPy and Matplotlib) to install for our notebooks.
*   **`demo/`**: An empty directory to store code examples and demonstrations provided during lectures.
*   **`labs/`**: Your working directory for regular course assignments.
*   **`term_project/`**: The dedicated folder for your final project materials.
*   **`Start_Jupyter_Mac.command` & `Start_Jupyter_Windows.bat`**: Shortcut scripts to launch the Jupyter environment.

---

## Setup Instructions

Please follow these steps to get your environment ready:

### 1. Install the uv Package Manager
Install the uv package manager. The installation instructions are at the uv website (https://docs.astral.sh/uv/getting-started/installation/)

### 2. Extract the Folder
Extract this entire folder from the `.zip` archive to a permanent location on your computer (e.g., your Documents folder). **Do not** attempt to run the scripts from inside the unextracted `.zip` file.

### 3. Launch Jupyter
Once the sync is complete and the packages are downloaded, run the appropriate startup script for your operating system:

*   **Windows:** Double-click `Start_Jupyter_Windows.bat`
*   **Mac:** Double-click `Start_Jupyter_Mac.command`

This will automatically open the Jupyter Notebook interface in your default web browser, where you can navigate into your `demo`, `labs`, or `term_project` folders to begin your work.