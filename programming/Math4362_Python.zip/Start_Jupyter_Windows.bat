@echo off
echo Syncing course packages and starting Jupyter Lab...
echo Please leave this window open while you work.
uv run jupyter lab
pause