#!/bin/bash
# Change to the directory where this script is located
cd "$(dirname "$0")"

echo "Syncing course packages and starting Jupyter Lab..."
echo "Please leave this terminal window open while you work."
uv run jupyter lab